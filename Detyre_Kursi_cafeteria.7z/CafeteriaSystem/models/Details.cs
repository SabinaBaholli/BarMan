﻿
using System;
namespace CafeteriaSystem
{
    class Details
    {
        public int ID;
        public string Name;
        public byte[] Picture;
        public decimal Price;
        public int Quantity;
        public decimal Total;
        public string Category;
        public string Description;
        public string Unit;

        public int SaleID;
        public DateTime SaleTime;
        public int SalesmanID;
    }
}
