﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CafeteriaSystem
{
    public partial class UpdateTables : Form
    {
        int TableID;
        string TableName;

        public UpdateTables(int GivenTableID, string GivenTableName)
        {
            InitializeComponent();
            TableID = GivenTableID;
            TableName = GivenTableName;
        }

        private void tableIdBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void UpdateTableButton_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("A jeni i sigurte qe doni ta ndryshoni kete tavoline?", "Warning", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                DataAccess _DataAccess = new DataAccess();

                int ProductID = Convert.ToInt32(tableIdBox.Text);

                string ProductName = tableNameBox.Text;

                if (_DataAccess.UpdateTable(ProductID, ProductName))
                {
                    this.Close();
                }
                else MessageBox.Show("Tavolina nuk u ndryshua", "Error", MessageBoxButtons.OK);
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void tableNameBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void UpdateTables_Load(object sender, EventArgs e)
        {

        }
    }
}
