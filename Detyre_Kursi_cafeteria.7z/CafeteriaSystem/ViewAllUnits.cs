﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CafeteriaSystem
{
    public partial class ViewAllUnits : Form
    {
        public ViewAllUnits()
        {
            InitializeComponent();
        }

        private void ViewAllUnits_Load(object sender, EventArgs e)
        {
            DataAccess _DataAccess = new DataAccess();

            foreach (Unit UnitDetail in _DataAccess.RetreiveAllUnitsFromDatabase())
            {
                dataGridView1.Rows.Add(UnitDetail.ID, UnitDetail.Name);
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
